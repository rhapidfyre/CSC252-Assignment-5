/**
 * @file    CSC252-Assignment-5.cpp
 * @authors Melanie Harris, ...
 * @date    05 OCT 2026
 * @version 0.1
 * @brief   Implementation and main driver for the Statistical Analysis assignment.
 * 
 * @license MIT
 */


// Assignment includes and usings.
#include "SelectionSort.h"
#include "BinarySearch.h"
#include "Analyzer.h"
#include "BinaryFile.h"
#include <iomanip>
using CSC252::BinarySearchTest;
using CSC252::SelectionSortTest;
using CSC252::StatisticsAnalyzerTest;
using CSC252::SearchAnalyzerTest;
using std::cout;
using std::endl;

// statics; Defines one string in one place.
#define TEST_DIR "tests/"
#define TEST_SELECTION_DIR "selection/"
#define TEST_BINARY_DIR "search/"
#define TEST_SEARCHANALYZER_DIR "searchanalyzer/"
#define TEST_STATISTICS_DIR "statistics/"
#define TITLE_SELECTIONSORT "Selection Sort"
#define TITLE_BINARYSEARCH "Binary Search"
#define TITLE_STATISTICS "Statistics Analyzer"
#define TITLE_SEARCHANALYZER "Search Analyzer"
#define DATA_FILE "values.dat"

// =============== HELPER FUNCTIONS ==================
namespace Helpers
{
    // Allows easy printing to the console with cout and newline already handled.
    static void print_console(const string& message) {cout << message << "\n";}
    
    // https://en.cppreference.com/cpp/utility/functional/invoke
    // Dynamic handling of a function to see if it throws an exception.
    template <typename Func, typename... Args>
    static bool Throws(Func&& FunctionCall, Args&&... Arguments)
    {
        try
            { std::invoke(std::forward<Func>(FunctionCall), std::forward<Args>(Arguments)...); }
        catch (const std::exception&)
            { return true; }
        return false;
    }
    
    // Implemented as a deeper version of the above dynamic handler, to see if the exception is what we expected to get.
    template <typename ExpectedException, typename Func, typename... Args>
    static bool ExpectThrow(Func&& FunctionCall, Args&&... Arguments)
    {
        try
            { std::invoke(std::forward<Func>(FunctionCall), std::forward<Args>(Arguments)...); }
        catch (const ExpectedException&)
            { return true; }
        return false;
    }
}
// ======== END HELPERS ========

namespace Tests
{
    const vector<string> SortTestDescriptions =
    {
        "Shuffle Test", "Shuffled Permutation", "Empty Array", "Single Element", "Already Sorted",
        "Reverse Sorted", "Same Value", "Mixed Duplicates", "Negatives & Extremes", "Two Elements",
        "Null Pointer Throw", "Negative Size Throw", "Null Size Zero", "Valid Array",
        "Empty; Valid Pointer"
    };
    
    const vector<string> SearchTestDescriptions = 
    {
        "Middle Value", "First Value", "Last Value", "Between Values", "Below Smallest",
        "Above Largest", "Single Element Found", "Single Element Missing", "Duplicates Found",
        "All Same Found", "All Same Missing", "Even Count Found", "Two Elements Second", "Empty Array",
        "Smallest Int", "Largest Int", "Range Whole Array", "Range Excludes Match", "Range Single Index",
        "Range Empty", "Null Array Throws", "Negative Size Throws", "Null Size Zero",
        "Range Null Throws", "Range Negative Start", "Range Null Empty", "Second Value",
        "Left Of Middle", "Right Of Middle", "Second To Last"
    };
    
    const vector<string> StatisticsTestDescriptions =
        {
        "Odd Count Unsorted", "Even Median Exact", "Even Median Remainder", "Single Element", "Two Equal Elements",
        "All Same", "Mode Tie First Wins", "Mode At End", "Mode At Start", "Mode Three Way Tie",
        "Negatives And Zero", "Largest Ints", "Smallest And Largest", "Empty Array", "Null Array Throws",
        "Null Size Zero", "All Unique Mode"
    };
    
    const vector<string> AnalyzerTestDescriptions =
    {
        "All Found", "None Found", "Empty Array", "Count Resets", "Null Array Throws", "Null Size Zero"
    };
    
    string FormatTestFile(const size_t TestNumber)
    {
        if (TestNumber < 10)
        {
            std::ostringstream TestLabel;
            TestLabel << std::setw(2) << std::setfill('0') << TestNumber;
            return TestLabel.str();
        }
        return std::to_string(TestNumber);
    }
    
    string TestDescription(const size_t TestNumber, const vector<string>& TestDescription)
    {
        std::ostringstream TestLabel;
        TestLabel << "Test " << std::setw(2) << std::setfill('0')
                  << TestNumber << " (" << TestDescription[TestNumber] << ")";
        return TestLabel.str();
    }
    
    /**
     * @brief A polymorphic method that can be used to run tests for any type of test object.
     * Once I started making the tests for Binary Search, I realized most of the test logic was rinse and repeat.
     * This method is a template that can be used to run tests for any type of test object.
     * 
     * @tparam TestType The test object type
     * @param TestTitle The title of the test group (i.e. Selection Sort)
     * @param TestDescriptions The descriptions of each test (i.e. "Test 01 (20 shuffled numbers)")
     * @return The number of tests failed.
     */
    template <typename TestType>
    int RunTests(const string& TestTitle, const vector<string>& TestDescriptions)
    {
        int TestsFailed{0};
        string TestDirectory{TEST_DIR};
        if (TestTitle == TITLE_SELECTIONSORT)
            TestDirectory += TEST_SELECTION_DIR;
        else if (TestTitle == TITLE_BINARYSEARCH)
            TestDirectory += TEST_BINARY_DIR;
        else if (TestTitle == TITLE_STATISTICS)
            TestDirectory += TEST_STATISTICS_DIR;
        else if (TestTitle == TITLE_SEARCHANALYZER)
            TestDirectory += TEST_SEARCHANALYZER_DIR;
        
        // unique_ptr: Handles garbage collection when scope is lost.
        // source: https://en.cppreference.com/cpp/memory/unique_ptr
        vector<std::unique_ptr<TestType>> SelectionSortTests;
    
        // future: The value doesn't exist now, but will after async is complete.
        // source: https://en.cppreference.com/cpp/thread/future
        vector<std::future<bool>> SelectionSortTestFutures;
        
        const int NumDescriptions = static_cast<int>(TestDescriptions.size());
        for (int TestNumber = 0; TestNumber < NumDescriptions; TestNumber++)
        {
            auto SortTestObject = std::make_unique<TestType>(TestNumber); // creates an object via smart pointers
            SortTestObject->SetInputFile(TestDirectory + FormatTestFile(TestNumber) + ".in");
            SortTestObject->SetOutputFile(TestDirectory + FormatTestFile(TestNumber) + ".out");
            SelectionSortTestFutures.push_back(SortTestObject->RunAsync()); // runs the test in a worker thread
        
            // IDE recommended "std::move"... Had to research it; Source: https://en.cppreference.com/cpp/utility/move
            // Turns out that std::move is used to move from its original source to the new object.
            SelectionSortTests.push_back(std::move(SortTestObject)); // keeps track of the test as it runs
        }
        
        for (size_t TestNumber = 0; TestNumber < SelectionSortTests.size(); TestNumber++)
        {
            SelectionSortTestFutures[TestNumber].get();
            const TestResult Result = SelectionSortTests[TestNumber]->GetResult();
        
            // Passed tests are silent. Only failures and errors are printed.
            if (Result.State == TestState::Passed)
                continue; // Move to next test
        
            TestsFailed++;
            if (Result.State == TestState::Error)
            {
                Helpers::print_console(TestTitle + " | " + TestDescription(TestNumber, TestDescriptions) + ": Errored. Reason: " + Result.Message);
                continue;
            }

            Helpers::print_console(TestTitle + " | " + TestDescription(TestNumber, TestDescriptions) + ": Failed. " + Result.Message);
        }

        // A group that passed completely stays silent, the same as a single test that passed.
        if (TestsFailed > 0)
            Helpers::print_console(TestTitle + " reported " + std::to_string(TestsFailed) + " test case failures.");

        return TestsFailed;
    }
}

bool ExecuteTestHarness()
{
    // Each group prints its own failures and its own failure count, and hands back that count.
    int TestsFailed{0};
    TestsFailed += Tests::RunTests<SelectionSortTest>(TITLE_SELECTIONSORT, Tests::SortTestDescriptions);
    TestsFailed += Tests::RunTests<BinarySearchTest>(TITLE_BINARYSEARCH, Tests::SearchTestDescriptions);
    TestsFailed += Tests::RunTests<StatisticsAnalyzerTest>(TITLE_STATISTICS, Tests::StatisticsTestDescriptions);
    TestsFailed += Tests::RunTests<SearchAnalyzerTest>(TITLE_SEARCHANALYZER, Tests::AnalyzerTestDescriptions);

    const size_t TotalTests = Tests::SortTestDescriptions.size()       + Tests::SearchTestDescriptions.size()
                            + Tests::StatisticsTestDescriptions.size() + Tests::AnalyzerTestDescriptions.size();
    
    if (TestsFailed > 0)
    {
        Helpers::print_console(
            "  All Tests Complete... "
            + std::to_string(TestsFailed) + "/"
            + std::to_string(TotalTests) + " tests failed.");
    }
    else
        Helpers::print_console("  All " + std::to_string(TotalTests) + " tests passed.");
    
    return TestsFailed == 0; // indicates success only on zero failures
}

/**
 * @brief Writes the data file, reads it back, and prints what each analyzer reports.
 *
 * @return False on failure/exception. True otherwise.
 */
bool ExecuteAnalysis()
{
    // This is where the real work starts, so anything thrown below is reported here instead of ending the program.
    try
    {
        createBinaryFile(DATA_FILE); // Failure to create can throw; Must be caught.
        const BinaryReader Reader(DATA_FILE); // Construction can fail; Must be caught.
        
        // Held through the base class, so each analyze() call runs the version that belongs to the real object.
        // Every analyzer clones the data, so one sorting its copy doesn't change what the next one is given.
        vector<std::unique_ptr<Analyzer>> Analyzers;
        Analyzers.push_back(std::make_unique<StatisticsAnalyzer>(Reader.getValues(), Reader.getSize()));
        Analyzers.push_back(std::make_unique<DuplicatesAnalyser>(Reader.getValues(), Reader.getSize()));
        Analyzers.push_back(std::make_unique<MissingAnalyser>(Reader.getValues(), Reader.getSize()));
        Analyzers.push_back(std::make_unique<SearchAnalyzer>(Reader.getValues(), Reader.getSize()));

        for (const std::unique_ptr<Analyzer>& AnalyzerObject : Analyzers)
            Helpers::print_console(AnalyzerObject->analyze());
    }
    catch (const std::exception& Error)
    {
        std::cerr << "Error: " << Error.what() << "\n";
        return false;
    }
    
    return true;
}

int main()
{
    // Only executes the test harness in debug mode.
    // Always executes the proper analytical output.
#ifdef _DEBUG
    if (!ExecuteTestHarness())
        return EXIT_FAILURE;
#endif
    return ExecuteAnalysis() ? EXIT_SUCCESS : EXIT_FAILURE;
}

